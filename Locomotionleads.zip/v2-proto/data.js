// Locomotion OS v2 — rich dataset
// Conversations, cores, earnings, integrations, blockers, dependencies, time-punches

window.PROTO_DATA = {
  shop: {
    name: "Locomotion Transmission — Austin",
    locations: ["Austin — Main", "Round Rock", "San Marcos"],
    integrations: {
      tekmetric: { status: "connected", lastSync: "2m ago", syncCount: 4821 },
      quickbooks: { status: "connected", lastSync: "1h ago", syncCount: 847 },
      stripe: { status: "connected", lastSync: "15m ago", charges: 12 },
      manychat: { status: "connected", lastSync: "now", messages: 284 },
      elevenlabs: { status: "connected", calls: 42 },
    },
  },
  users: {
    manager: { name: "Dana Okafor", role: "MANAGER", initials: "DO", avatar: "🟨" },
    advisor: { name: "Marco Reyes", role: "SERVICE_ADVISOR", initials: "MR", avatar: "🟦" },
    tech1: { name: "Jules Park", role: "TECHNICIAN", initials: "JP", avatar: "🟩" },
    tech2: { name: "Tomás Barrera", role: "TECHNICIAN", initials: "TB", avatar: "🟪" },
    tech3: { name: "Amina Kone", role: "TECHNICIAN", initials: "AK", avatar: "🟥" },
    accounting: { name: "Priya Sharma", role: "ACCOUNTING", initials: "PS", avatar: "🟧" },
  },
  kpis: {
    revenueMTD: 184720,
    revenueGoal: 240000,
    activeWOs: 47,
    cycleTimeDays: 5.8,
    marginPct: 42.3,
    unpaid: 38920,
  },
  stateSentence: {
    heading: "You have <em>3 approvals waiting</em>, <em>1 job 48h overdue</em>, and <em>$38.9k unpaid</em>.",
    subtext: "Everything else is on track — 47 active work orders, 4 in QC, margin at 42.3%.",
    actions: [{ label: "Review approvals", link: "approvals" }],
  },
  workOrders: [
    { ro: "RO-4821", customer: "Linda Chen", vehicle: "2019 Ford F-150", vin: "1FTEW1EP5KFA12345", phase: "diagnosis", advisor: "MR", tech: "JP", days: 2, total: 3820, concern: "Shudder 2-3 shift, CEL", flag: null, risk: 0.34, messages: 4, evidence: 2, nextSteps: "Torque converter inspection", workflow: "Diagnostic", checklist: { items: 5, done: 2 } },
    { ro: "RO-4822", customer: "Carlos Mendez", vehicle: "2016 Honda Odyssey", vin: "5FNRL5H68GB098234", phase: "parts", advisor: "MR", tech: "AK", days: 5, total: 5240, concern: "Won't shift 2nd, limp", flag: "waiting", risk: 0.67, messages: 8, evidence: 3, nextSteps: "Rebuild kit ETA Thu 3pm", workflow: "Rebuild", checklist: { items: 12, done: 7 } },
    { ro: "RO-4823", customer: "Sarah Weinstein", vehicle: "2022 Tesla Model Y", vin: "7SAYGDEE2NF123456", phase: "install", advisor: "MR", tech: "JP", days: 3, total: 8950, concern: "Rear motor replacement", flag: null, risk: 0.12, messages: 2, evidence: 5, nextSteps: "Test drive & delivery", workflow: "Motor Swap", checklist: { items: 8, done: 6 } },
    { ro: "RO-4824", customer: "Harold Kim", vehicle: "2014 Chevy Silverado", vin: "1GCVKREC8EZ234567", phase: "install", advisor: "MR", tech: "TB", days: 7, total: 4680, concern: "Rebuild 4L60E, slipping", flag: "overdue", risk: 0.89, messages: 12, evidence: 8, nextSteps: "Complete test drive", workflow: "Rebuild", checklist: { items: 11, done: 9 } },
    { ro: "RO-4825", customer: "Jessica Patel", vehicle: "2020 Subaru Outback", vin: "4S4BTAFC9L3345678", phase: "qc", advisor: "MR", tech: "JP", days: 4, total: 6120, concern: "CVT whining, shudder", flag: null, risk: 0.21, messages: 6, evidence: 4, nextSteps: "Final inspection", workflow: "CVT Service", checklist: { items: 9, done: 8 } },
    { ro: "RO-4826", customer: "Miguel Torres", vehicle: "2018 Toyota Tacoma", vin: "3TMAZ5CN9JM456789", phase: "diagnosis", advisor: "MR", tech: "AK", days: 1, total: 980, concern: "Fluid leak, seal check", flag: null, risk: 0.28, messages: 1, evidence: 1, nextSteps: "Order replacement seal", workflow: "Seal Replacement", checklist: { items: 4, done: 1 } },
    { ro: "RO-4827", customer: "Robin Acosta", vehicle: "2017 Jeep Wrangler", vin: "1C4BJWDG7HL567890", phase: "delivery", advisor: "MR", tech: "TB", days: 8, total: 4120, concern: "Hard 1-2, valve body", flag: null, risk: 0.05, messages: 3, evidence: 2, nextSteps: "Ready for pickup", workflow: "Valve Body Replacement", checklist: { items: 6, done: 6 } },
    { ro: "RO-4828", customer: "Veridian Logistics", vehicle: "2021 Ford Transit 250", vin: "1FTBR1Y85MKA78901", phase: "parts", advisor: "MR", tech: null, days: 2, total: 2140, concern: "60k service + shudder", flag: "approval", risk: 0.19, messages: 5, evidence: 0, nextSteps: "Awaiting fleet approval", workflow: "Fleet Service", checklist: { items: 7, done: 3 } },
    { ro: "RO-4829", customer: "Amelia Rosen", vehicle: "2015 BMW 328i", vin: "WBA3A5C50FF789012", phase: "intake", advisor: "MR", tech: null, days: 0, total: 0, concern: "ZF8HP shudder", flag: null, risk: 0.42, messages: 0, evidence: 0, nextSteps: "Schedule diagnosis", workflow: "ZF8HP Service", checklist: { items: 3, done: 0 } },
    { ro: "RO-4830", customer: "David Oyelowo", vehicle: "2019 Ram 1500", vin: "1C6RR7LT5KS890123", phase: "diagnosis", advisor: "MR", tech: "JP", days: 1, total: 1840, concern: "P0700, no forward gears", flag: "approval", risk: 0.76, messages: 9, evidence: 3, nextSteps: "TCM replacement labor +$420", workflow: "TCM Replacement", checklist: { items: 5, done: 2 } },
  ],
  conversations: [
    { id: 1, ro: "RO-4821", customer: "Linda Chen", platform: "messenger", msgs: [
      { time: "2h", who: "customer", text: "When will I hear about the diagnosis?" },
      { time: "2h", who: "shop", text: "Jules is on it now. Should have estimate by end of day." },
      { time: "1h", who: "customer", text: "Ok great, thanks!" },
    ]},
    { id: 2, ro: "RO-4824", customer: "Harold Kim", platform: "messenger", msgs: [
      { time: "4h", who: "customer", text: "Is my truck done yet?" },
      { time: "4h", who: "shop", text: "Almost! In final QC now. Ready tomorrow morning." },
      { time: "2h", who: "customer", text: "Perfect. See you then." },
    ]},
  ],
  cores: [
    { sku: "ZF-8HP-CORE", description: "ZF8HP Transmission Core", state: "inbound", eta: "Fri", credit: 450, vendor: "ZF Remanufacturing" },
    { sku: "4L60E-CORE", description: "4L60E Transmission Core", state: "received", date: "Mar 18", credit: 320, vendor: "Jasper Engines" },
    { sku: "CVT-NISSAN-CORE", description: "Nissan CVT Core", state: "shipped", eta: "Today", credit: 280, vendor: "ATP Automotive" },
  ],
  technicians: [
    { name: "Jules Park", initials: "JP", mtdEarnings: 12840, streak: 14, completions: 18, rework: 1, nextLevel: "Senior Tech (5 more jobs)" },
    { name: "Tomás Barrera", initials: "TB", mtdEarnings: 9620, streak: 8, completions: 14, rework: 0, nextLevel: "Journeyman (3 more)" },
    { name: "Amina Kone", initials: "AK", mtdEarnings: 7920, streak: 5, completions: 11, rework: 2, nextLevel: "Journeyman (4 more)" },
  ],
  blockers: [
    { ro: "RO-4824", type: "parts", item: "4L60E rebuild kit", eta: "Tomorrow 10am", duration: "22h", impact: "high", assigned: "AK" },
    { ro: "RO-4822", type: "approval", item: "Estimate ($5.2k)", waiting: "18h", impact: "medium", assigned: "MR" },
    { ro: "RO-4830", type: "labor", item: "TCM replacement authorization", waiting: "28h", impact: "high", assigned: "Dana" },
  ],
  approvals: [
    { ro: "RO-4822", customer: "Carlos Mendez", type: "Estimate", amount: 5240, waiting: 18, reason: "Rebuild + torque converter" },
    { ro: "RO-4828", customer: "Veridian Logistics", type: "Fleet PO", amount: 2140, waiting: 3, reason: "Fleet manager review" },
    { ro: "RO-4830", customer: "David Oyelowo", type: "Labor", amount: 420, waiting: 28, reason: "TCM replacement mid-repair" },
  ],
  invoices: [
    { num: "INV-2113", ro: "RO-4820", customer: "Priya Ramaswamy", amount: 5820, status: "unpaid", dueIn: 22 },
    { num: "INV-2112", ro: "RO-4819", customer: "Farida Oumar", amount: 2640, status: "unpaid", dueIn: 7 },
    { num: "INV-2111", ro: "RO-4817", customer: "Jordan Blake", amount: 3150, status: "overdue", dueIn: -6 },
  ],
};
